import {defineCypressTests} from "../../../../coreTests/defineCypress";
import * as SegmentToolTests from "../../../../coreTests/testCases/segment";


defineCypressTests("Segment Tool", SegmentToolTests);
