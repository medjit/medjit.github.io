import React from "react";
import {ApplicationContext} from "cad/context";

export const StreamsContext = React.createContext<ApplicationContext>(null);