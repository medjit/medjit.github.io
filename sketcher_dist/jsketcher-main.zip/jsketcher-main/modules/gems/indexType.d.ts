
export type Index<T> = {
  [key: string]: T
};
