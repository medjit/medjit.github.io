import {allPropsDefined} from "gems/objects";

export const checkAllPropsDefined = obj => allPropsDefined(obj) ? obj : null;
