export class UV {
  
  constructor(u, v) {
    this.u = u;
    this.v = v;
  }
}