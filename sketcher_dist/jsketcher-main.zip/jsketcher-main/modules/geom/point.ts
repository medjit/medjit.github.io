import Vector from 'math/vector';

export const Point = Vector;