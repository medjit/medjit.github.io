# EXTRUDE
The EXTRUDE command allows for selection of a face or sketch to be extruded.

By default the extrude direction is perpendicular to the selected face. A extrude direction vector can be specified by selecting an existing edge, sketch line or existing face.
 
The boolean drop down and target allows for boolean operations with existing 3d solids. 