# SHELL
The SHELL feature allows for creation of a new bodyas the result of hollowing out an exising body. The faces you select are removed from the object and the thickness specified is used to create the new offset faces making the shell. 

Multiple faces can be selected. For example if the top and bottom faces of a cylinder were selected a hollow tube with the thickness specified would be created. 
