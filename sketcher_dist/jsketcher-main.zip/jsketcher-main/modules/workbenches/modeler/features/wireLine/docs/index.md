# Wire Line
This tool allows for creation of a line element by selecting two datum points.