# BOX
The BOX command can be accesed by hovering over the center point of an existing datum and clicking. This brings up a menue with the BOX command as an option. 

Size of the box can be specified with the X, Y and Z size fields. 
The boolean drop down and target allows for boolean operations with existing 3d solids. 