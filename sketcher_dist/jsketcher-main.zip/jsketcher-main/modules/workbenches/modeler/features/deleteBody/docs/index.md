# DELETE BODY
This commands allows deletion of selected shell objects.