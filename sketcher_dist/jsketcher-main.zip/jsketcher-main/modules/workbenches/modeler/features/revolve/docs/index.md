# REVOLVE
The REVOLVE command allows for selection of a face or sketch to be revolved about a centerline.
The Angle field allows you to specify in degrees where the end face of the revolve is created. Specifying an angle of 360 creates a full revolution wile specifying 90 would result in 1/4 of a complete revolution. The revolution starts from the face or sketch selected.

The Vector specifies the revolution axis. This can be supplied as a sketch segment or edge of existing geometry in the model.
 
The boolean drop down and target allows for boolean operations with existing 3d solids. 