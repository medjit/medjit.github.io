# CONE
The CONE command can be accesed by hovering over the center point of an existing datum and clicking. This brings up a menue with the CONE command as an option. 

Size of the CONE can be specified with the Diameter A, Diameter A and Height fields. Specifying a value of 0 for either of the diameter fields will create a cone with a sharp point.
The boolean drop down and target allows for boolean operations with existing 3d solids. 