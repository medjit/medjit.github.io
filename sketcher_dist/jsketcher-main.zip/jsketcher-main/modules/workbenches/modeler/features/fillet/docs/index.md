# FILLET/CHAMPER 
Using the fillet or champer operation allows for breaking of edges of a shell.

You must select at least one edge and specify the size value.

In the case of a fillet a the size (radius) is specified and will result in rounded corners of the size values for each selected edge.

In the case of a champer the edge of each face adjacent to the selected edge are pushed back by the size distance. A new face is created to patch the hole left by moving the faces edges back. 