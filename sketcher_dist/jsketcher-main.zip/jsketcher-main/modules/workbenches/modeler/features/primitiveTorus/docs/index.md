# TORUS
The TORUS command can be accesed by hovering over the center point of an existing datum and clicking. This brings up a menue with the TORUS command as an option. 

Size of the TORUS can be specified with the Radius and Tube Radius fields. 
The boolean drop down and target allows for boolean operations with existing 3d solids. 