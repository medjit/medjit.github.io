# DELETE FACE 
The delete face tool is used to defeature a model. 

Select the faces you wish to remove. For example a particular fillet or the bottom and side faces of a hole.

The tool will attempt to extend adjacent faces to fill the hole. 

Useful for working with geometry that has been imported or being prepared for developing a casting where the features will be added at a later stage of the manufacturing process. 