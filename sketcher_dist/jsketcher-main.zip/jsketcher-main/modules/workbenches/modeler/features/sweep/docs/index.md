# SWEEP
The sweep command allows for extruding a loop following a guide path.
It is useful for creating more complex geometry than you could make with a regular linear extrude. 

It also allows for specifying how each corner of linear segments should be handled. They can either make sharp corners or automatically add round them. 