export interface XYZ {

  x: number;
  y: number;
  z: number;

}