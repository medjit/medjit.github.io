import Vector from "math/vector";

export type VectorTransformer = (Vector) => Vector;