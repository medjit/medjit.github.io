export default ((window.devicePixelRatio) ? window.devicePixelRatio : 1);
