/**
 * Represents a notion of an internal reference of an engine. For example a pointer in web assembly code
 */
export type Handle = number;
