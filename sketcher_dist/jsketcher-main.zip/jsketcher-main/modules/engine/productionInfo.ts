export interface ProductionInfo {

  role: string;

  originatedFromPrimitive: string;

  derived?: ProductionInfo[];

}