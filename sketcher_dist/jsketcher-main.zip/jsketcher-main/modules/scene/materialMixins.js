
export const OnTopOfAll = {
  depthWrite: false,
  depthTest: false,
  renderOrder: 1e11
};
