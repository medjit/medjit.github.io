import * as THREE from 'three';
window.THREE = THREE;

