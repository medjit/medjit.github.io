Related issue: #XXXX  (if applicable)
=========================

Description:
=========================
A clear and concise description of what the problem was and how this pull request solves it.
If pull request is for a new feature a clear description of the feature and usage.


Contributor name: XXXXX
=========================


Confirm compliance with JSketcher project license. 
=========================
- [x] Pull request is made compliance with JSKetcher license  