First off. You are awesome. Thanks for wanting to help contribute to the JSketcher project. 

To make things easier to manage we have some guidelines that will help to keep the codebase clean and tidy. 

1. No merge commits. Everything should be rebased on top of the main branch. History should be one line/linear
2. No unnecessary formatting/prettifiyng. Only for the neighborhood of the actual change.
3. Indent is always 2 spaces. 
4. Execute  ```npm run before-main-branch-merge``` to statically check and lint the code.